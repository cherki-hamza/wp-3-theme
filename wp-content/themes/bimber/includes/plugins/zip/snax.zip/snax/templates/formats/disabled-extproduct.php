<?php
/**
 * Disable format message
 *
 * @package snax
 * @subpackage Theme
 */

echo esc_html_x( 'Activate WooCommerce plugin to use this format', 'Disabled format reason', 'snax' );