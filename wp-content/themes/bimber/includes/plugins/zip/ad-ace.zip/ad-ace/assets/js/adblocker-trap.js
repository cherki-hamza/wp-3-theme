/* global jQuery */
/* global document */

document.getElementById('adace-adblocker-detected').style.display = 'none';
document.getElementById('adace-adblocker-not-detected').style.display = 'block';
