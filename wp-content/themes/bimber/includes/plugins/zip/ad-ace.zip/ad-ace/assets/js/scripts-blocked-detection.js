/* global document */

// Fire as fast as possible.
window.adaceScriptsLoaded = true;
