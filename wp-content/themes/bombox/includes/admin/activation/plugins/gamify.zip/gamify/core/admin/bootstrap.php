<?php

// Prevent direct script access.
if ( ! defined( 'ABSPATH' ) ) {
	die( 'No direct script access allowed' );
}

require_once GFY_ADMIN_DIR . 'classes/class-admin-notifier.php';
require_once GFY_ADMIN_DIR . 'functions.php';