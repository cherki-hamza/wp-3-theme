<div class="zf-type-wrapper"><i class="zf-icon zf-icon-type-audio"></i></div>

<div class="zf-audio-container">
        <div class="zf-audio_container">
                <?php echo $this->renderGroups(['story', 'audio', 'audio'], $group_name_prefix, $data, $action, ['story', 'audio'], 'audio', '', ''); ?>
        </div>
</div>