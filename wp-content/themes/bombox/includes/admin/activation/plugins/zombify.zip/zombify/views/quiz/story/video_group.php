<div class="zf-type-wrapper"><i class="zf-icon zf-icon-type-video"></i></div>

<div class="zf-video-container">
        <div class="zf-video_container">
                <?php echo $this->renderGroups(['story', 'video', 'video'], $group_name_prefix, $data, $action, ['story', 'video'], 'video', '', ''); ?>
        </div>
</div>