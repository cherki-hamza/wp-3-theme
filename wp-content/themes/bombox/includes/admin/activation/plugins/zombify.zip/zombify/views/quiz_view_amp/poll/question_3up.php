<?php
$answersType = 'zfPollMedia';
$answersCol = 'zf3col';
include zombify()->locate_template( zombify()->quiz_view_dir('poll/question.php'));
