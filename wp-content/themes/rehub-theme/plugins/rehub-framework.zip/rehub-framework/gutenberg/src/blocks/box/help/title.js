const {__} = wp.i18n;
export default  __('Info box', 'rehub-framework');
