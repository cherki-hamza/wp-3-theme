const slug = 'titlebox';
export default slug;
